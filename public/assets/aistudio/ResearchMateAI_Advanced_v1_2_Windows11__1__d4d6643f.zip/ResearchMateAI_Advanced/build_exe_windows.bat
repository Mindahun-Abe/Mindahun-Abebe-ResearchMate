@echo off
cd /d "%~dp0"
py -3 -m pip install -r requirements.txt pyinstaller
if errorlevel 1 (echo Dependency install failed. & pause & exit /b 1)
py -3 -m PyInstaller --noconfirm --name ResearchMateAIAdvanced --add-data "researchmate;researchmate" main.py
pause
