
import os, json, csv, io, hashlib
from pathlib import Path
from collections import defaultdict
from flask import Flask, render_template_string, request, redirect, url_for, flash, send_file, jsonify
from . import db
from .metadata import extract_file, file_hash, title_similarity, normalize_doi
from . import crossref
from .screening import screen
from .proposal import build_proposal, export_docx
from . import results as R
from flask import Response

UPLOAD_DIR=db.APP_DIR/"imports"; UPLOAD_DIR.mkdir(exist_ok=True)

HTML=r"""
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>ResearchMate AI Advanced</title>
<style>
:root{--navy:#17324d;--teal:#087f78;--bg:#f4f7fa;--line:#dbe3ea;--muted:#627387}
*{box-sizing:border-box}body{margin:0;font:14px/1.45 "Segoe UI",Arial,sans-serif;background:var(--bg);color:#172b3d}
header{background:var(--navy);color:white;padding:18px 24px;display:flex;justify-content:space-between;align-items:center;gap:16px;flex-wrap:wrap}
header h1{margin:0;font-size:22px}header p{margin:4px 0 0;color:#c9d6e3}
nav{background:#fff;border-bottom:1px solid var(--line);padding:0 20px;display:flex;gap:5px;flex-wrap:wrap}
nav a{padding:13px 12px;text-decoration:none;color:var(--navy);border-bottom:3px solid transparent;font-weight:600}
nav a:hover{border-color:var(--teal);background:#f5fbfa}
main{max-width:1400px;margin:22px auto;padding:0 18px}.card{background:white;border:1px solid var(--line);border-radius:12px;padding:18px;margin-bottom:16px;box-shadow:0 2px 7px #102b3b08}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:12px}.metric{padding:18px;border:1px solid var(--line);border-radius:10px;background:#fff}.metric strong{font-size:28px;display:block;color:var(--teal)}
h2{font-size:19px;margin:0 0 14px}h3{font-size:16px;margin:16px 0 8px}
label{display:block;font-weight:600;margin:8px 0 4px}input,textarea,select{font:inherit;width:100%;border:1px solid #c9d5df;border-radius:7px;padding:9px;background:#fff;color:#172b3d}
textarea{min-height:75px;resize:vertical}.row{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:12px}
button,.button{background:var(--teal);color:white;border:0;border-radius:7px;padding:9px 13px;font:600 14px "Segoe UI",Arial;cursor:pointer;text-decoration:none;display:inline-block;margin:6px 4px 0 0}
button.secondary,.button.secondary{background:#e8eef3;color:#17324d}button.danger{background:#a33e42}
table{border-collapse:collapse;width:100%;background:white;font-size:13px}th,td{text-align:left;padding:9px;border-bottom:1px solid var(--line);vertical-align:top}th{background:#edf3f7;position:sticky;top:0}td{max-width:450px;overflow-wrap:anywhere}
.table-wrap{overflow:auto;max-height:65vh;border:1px solid var(--line);border-radius:8px}.muted{color:var(--muted)}.pill{display:inline-block;border-radius:99px;padding:3px 8px;background:#e9f4f3;color:#17645f;font-size:12px}.uncertain{background:#fff4d8;color:#7a5810}.exclude{background:#fbe9e9;color:#8b3030}.include{background:#e4f5ea;color:#22633a}.flash{padding:10px;border-radius:7px;background:#eaf5ee;margin:10px 0}.small{font-size:12px}.evidence{white-space:pre-wrap;background:#f6f8fa;border-left:3px solid #90a8b7;padding:9px;margin:6px 0}
.review-layout{display:grid;grid-template-columns:minmax(0,1.2fr) minmax(330px,.8fr);gap:16px;align-items:start}
.article-pane,.decision-pane{min-width:0}.article-text{height:68vh;overflow:auto;border:1px solid var(--line);border-radius:8px;padding:14px;background:#fbfcfd;white-space:pre-wrap;font:13px/1.6 Consolas,monospace}
.page-chip{display:inline-block;background:#e8eef3;border-radius:4px;padding:2px 6px;color:#17324d;font:600 11px "Segoe UI",Arial;margin:8px 0}
.ev-card{border:1px solid var(--line);border-radius:8px;padding:10px;margin:8px 0;background:#fff}.ev-card blockquote{margin:8px 0;padding:8px;border-left:3px solid var(--teal);background:#f2f8f7}
.review-controls{position:sticky;top:12px;max-height:85vh;overflow:auto}
@media(max-width:900px){.review-layout{grid-template-columns:1fr}.article-text{height:45vh}.review-controls{position:static;max-height:none}}
</style></head><body>
<header><div><h1>ResearchMate AI <span style="color:#86d8cc">Advanced</span></h1><p>Local research library · transparent screening · evidence trail · proposal drafting</p></div><span class="pill">Local-only server</span></header>
<nav>
<a href="/">Dashboard</a><a href="/project">Project & criteria</a><a href="/library">Article library</a><a href="/duplicates">Duplicates</a><a href="/screening">Eligibility screening</a><a href="/results">Output results</a><a href="/writer">Project information writer</a><a href="/audit">Audit trail</a>
</nav><main>
{% with messages=get_flashed_messages() %}{% for m in messages %}<div class="flash">{{m}}</div>{% endfor %}{% endwith %}
{{body|safe}}
</main>
<script>
document.querySelectorAll("form[data-confirm]").forEach(f=>f.addEventListener("submit",e=>{if(!confirm(f.dataset.confirm))e.preventDefault()}));
</script></body></html>
"""
def page(body, **kwargs):
    return render_template_string(HTML,body=render_template_string(body,**kwargs))

def criteria():
    p=db.project()
    p["review_title"]=p.get("review_title") or ""
    return p

def parse_reference_file(path):
    ext=Path(path).suffix.lower()
    records=[]
    if ext==".csv":
        with open(path,newline="",encoding="utf-8-sig",errors="replace") as f:
            for row in csv.DictReader(f):
                r={str(k).lower().strip():v for k,v in row.items() if k}
                def pick(*keys):
                    return next((r[k] for k in keys if r.get(k)), "")
                try: year=int(str(pick("year","publication year","date"))[:4])
                except: year=None
                records.append({"title":pick("title","article title"),"authors":pick("authors","author"),"year":year,
                    "doi":pick("doi"),"journal":pick("journal","source"),"abstract":pick("abstract"),
                    "keywords":pick("keywords"),"article_type":pick("type","document type") or "journal article",
                    "file_path":str(path),"project_id":1})
    elif ext==".ris":
        cur={}
        for line in Path(path).read_text(encoding="utf-8",errors="replace").splitlines():
            if line.startswith("ER  -"):
                if cur:
                    cur["authors"]="; ".join(cur.get("authors",[])) if isinstance(cur.get("authors"),list) else cur.get("authors","")
                    try: cur["year"]=int(str(cur.get("year",""))[:4])
                    except: cur["year"]=None
                    cur["file_path"]=str(path); records.append(cur)
                cur={}; continue
            if len(line)>=6 and line[2:6]=="  -":
                tag,val=line[:2],line[6:].strip()
                key={"TI":"title","T1":"title","AU":"authors","PY":"year","Y1":"year","DO":"doi","JO":"journal","JF":"journal","AB":"abstract","KW":"keywords","TY":"article_type"}.get(tag)
                if key:
                    if key=="authors": cur.setdefault(key,[]).append(val)
                    elif key in cur and key in ("abstract","keywords"): cur[key]+="; "+val
                    else: cur[key]=val
        if cur:
            cur["authors"]="; ".join(cur.get("authors",[])) if isinstance(cur.get("authors"),list) else cur.get("authors","")
            try: cur["year"]=int(str(cur.get("year",""))[:4])
            except: cur["year"]=None
            cur["file_path"]=str(path); records.append(cur)
    else:
        rec=extract_file(path); records=[rec]
    return records


R_TEMPLATE={
 "name":"UAV crop-health systematic review",
 "review_title":"Unmanned Aerial Vehicles and Ultra-High-Resolution Remote Sensing for Real-Time Crop Health Monitoring: A Systematic Review of Sensor Technologies, Flight Planning, and Micro-Scale Stress Detection",
 "discipline":"Agricultural remote sensing / precision agriculture","study_area":"",
 "year_start":2015,"year_end":2026,
 "research_question":"RQ1 | Which UAV platforms and sensors are used? | Drone type; RGB, multispectral, thermal, hyperspectral sensors\nRQ2 | How is micro-scale crop stress detected? | Plant, canopy and field resolution; stress type\nRQ3 | How does flight planning affect monitoring performance? | Altitude, GSD, overlap, speed, flight time, weather\nRQ4 | Which analytical methods provide the best results? | Vegetation indices, ML, DL, sensor fusion\nRQ5 | How close are published workflows to real-time operation? | Acquisition-to-result time, processing, communication\nRQ6 | How reliable are results across crops, sites and seasons? | Validation design, ground truth, metrics, external testing\nRQ7 | What prevents operational deployment? | Cost, battery life, calibration, regulations, data volume, scalability",
 "objectives":"1. Identify UAV platforms and sensor technologies used for crop health monitoring.\n2. Evaluate how multispectral, thermal, RGB and other high-resolution sensors detect crop stress at plant, leaf, canopy and field scales.\n3. Assess the effects of flight altitude, speed, overlap, illumination, timing and weather on image quality and monitoring performance.\n4. Compare image-processing methods, vegetation indices, machine-learning models and sensor-fusion approaches.\n5. Evaluate monitoring latency, detection accuracy, spatial resolution, transferability and field-level validation.\n6. Identify research gaps and develop a framework for operational, near-real-time crop health monitoring.",
 "required_terms":"crop",
 "any_terms":"UAV, drone, unmanned aerial, uncrewed aerial, multispectral, thermal, hyperspectral, remote sensing, crop stress, crop health, plant health, precision agriculture, ground sampling distance, flight planning, near-real-time, real-time",
 "excluded_terms":"satellite-only, editorial, opinion, protocol",
 "allowed_types":"Peer-reviewed original empirical research and eligible full conference papers; exclude editorials, opinion pieces and records without eligible results",
 "search_strategy":'("unmanned aerial vehicle*" OR UAV OR drone* OR "uncrewed aerial vehicle*") AND ("crop health" OR "crop stress" OR "plant health" OR "crop monitoring" OR "precision agriculture") AND ("remote sensing" OR multispectral OR thermal OR hyperspectral OR "RGB imaging" OR "sensor fusion"). Run a broader core search first, then a complementary search on flight planning, spatial resolution and latency.',
 "db_counts":"Scopus | | \nWeb of Science | | \nIEEE Xplore | | \nScienceDirect | | \nCAB Abstracts | | \nGoogle Scholar (supplementary) | | ",
 "work_plan":""}

def create_app():
    db.initialize()
    app=Flask(__name__); app.secret_key="local-researchmate-session-key"
    @app.get("/")
    def dashboard():
        arts=db.articles()
        counts={"articles":len(arts),"include":sum(a.get("decision")=="Include" and a.get("is_final") for a in arts),
                "exclude":sum(a.get("decision")=="Exclude" and a.get("is_final") for a in arts),
                "uncertain":sum(not a.get("decision") or a.get("decision")=="Uncertain" for a in arts)}
        body="""<div class="grid">
        <div class="metric"><span class="muted">Library records</span><strong>{{c.articles}}</strong></div>
        <div class="metric"><span class="muted">Final includes</span><strong>{{c.include}}</strong></div>
        <div class="metric"><span class="muted">Final excludes</span><strong>{{c.exclude}}</strong></div>
        <div class="metric"><span class="muted">Uncertain / unreviewed</span><strong>{{c.uncertain}}</strong></div></div>
        <section class="card"><h2>Getting started</h2><ol>
        <li>Set your discipline, review title, year range, and flexible screening terms in <b>Project & criteria</b>.</li>
        <li>Import PDFs, DOCX, TXT, RIS, or CSV records into the library.</li><li>Scan for exact duplicate files.</li>
        <li>Run assisted screening and inspect evidence snippets.</li><li>Record a reviewer decision and mark it final only after human review.</li>
        <li>Generate a proposal scaffold from records marked Include and final.</li></ol>
        <p class="muted">Screening suggestions are not final decisions. Peer review and publication type must be verified by a person.</p></section>
        <section class="card"><h2>Current project</h2><p><b>{{p.name}}</b></p><p>{{p.review_title}}</p><p class="muted">{{p.discipline}} · Years {{p.year_start}}–{{p.year_end}}</p><a class="button" href="/project">Edit criteria</a> <a class="button" href="/library">Import and search articles</a> <a class="button" href="/results">Output results</a> <a class="button" href="/writer">Write project information</a></section>"""
        return page(body,c=counts,p=criteria())

    @app.route("/project",methods=["GET","POST"])
    def project_page():
        if request.method=="POST":
            d={k:request.form.get(k,"").strip() for k in ["name","review_title","discipline","research_question","study_area","required_terms","any_terms","excluded_terms","allowed_types","objectives","search_strategy","db_counts","work_plan"]}
            try: d["year_start"]=int(request.form.get("year_start","2015")); d["year_end"]=int(request.form.get("year_end","2026"))
            except ValueError: flash("Years must be numeric."); return redirect(url_for("project_page"))
            if d["year_start"]>d["year_end"]: flash("Start year must not be later than end year."); return redirect(url_for("project_page"))
            db.save_project(d,request.form.get("reviewer") or "Researcher"); flash("Project criteria saved; audit event recorded."); return redirect(url_for("project_page"))
        p=criteria()
        body="""<section class="card"><h2>Project and eligibility criteria</h2><p class="muted">Works across disciplines. Terms are evidence-finding aids, not a complete substitute for reading the article. Separate terms with commas or new lines.</p>
        <form method="post"><div class="row"><div><label>Project name</label><input name="name" value="{{p.name}}"></div>
        <div><label>Review title / topic</label><input name="review_title" value="{{p.review_title}}"></div><div><label>Discipline / subject</label><input name="discipline" value="{{p.discipline}}"></div></div>
        <label>Research questions (one per line, e.g. RQ1 | question | evidence to collect)</label><textarea name="research_question">{{p.research_question}}</textarea>
        <label>Study area / population (optional)</label><input name="study_area" value="{{p.study_area}}">
        <div class="row"><div><label>Start publication year</label><input type="number" name="year_start" value="{{p.year_start}}" min="1900" max="2200"></div><div><label>End publication year</label><input type="number" name="year_end" value="{{p.year_end}}" min="1900" max="2200"></div></div>
        <label>Required terms (AND-like; absence triggers Uncertain, not automatic exclusion)</label><textarea name="required_terms">{{p.required_terms}}</textarea>
        <label>Any-of terms (OR-like; at least one expected)</label><textarea name="any_terms">{{p.any_terms}}</textarea>
        <label>Potential exclusion terms (flag for human review)</label><textarea name="excluded_terms">{{p.excluded_terms}}</textarea>
        <label>Review objectives (one per line)</label><textarea name="objectives" style="min-height:130px">{{p.objectives}}</textarea>
        <label>Search strategy (Boolean string; save each database search separately in your records)</label><textarea name="search_strategy">{{p.search_strategy}}</textarea>
        <label>Databases searched (one per line: name | search date | records retrieved)</label><textarea name="db_counts">{{p.db_counts}}</textarea>
        <label>Work plan notes (optional; phases, milestones, dates)</label><textarea name="work_plan">{{p.work_plan}}</textarea>
        <label>Eligible document types / policy note</label><input name="allowed_types" value="{{p.allowed_types}}">
        <label>Reviewer / actor name for audit log</label><input name="reviewer" value="Researcher">
        <button>Save project and criteria</button></form>
        <form method="post" action="/project/template" data-confirm="Replace the current project fields with the UAV crop-health systematic-review template?"><button class="secondary">Load UAV crop-health review template</button></form></section>"""
        return page(body,p=p)

    @app.route("/library",methods=["GET","POST"])
    def library():
        if request.method=="POST":
            uploaded=request.files.getlist("files")
            added=skipped=0; errors=[]
            for f in uploaded:
                if not f or not f.filename: continue
                name=Path(f.filename).name
                target=UPLOAD_DIR/name
                if target.exists():
                    target=UPLOAD_DIR/(target.stem+"_"+hashlib.sha1(f.filename.encode()).hexdigest()[:7]+target.suffix)
                try:
                    f.save(target)
                    ext=target.suffix.lower()
                    if ext in {".pdf",".docx",".txt"}:
                        rec=extract_file(str(target))
                    elif ext in {".csv",".ris"}:
                        # Parse records from uploaded bibliography file, not just one row.
                        records=parse_reference_file(target)
                        for rec in records:
                            _,ok=db.add_article(rec,request.form.get("reviewer") or "Researcher")
                            added+=int(ok); skipped+=int(not ok)
                        continue
                    else:
                        errors.append(f"{name}: unsupported extension"); continue
                    _,ok=db.add_article(rec,request.form.get("reviewer") or "Researcher")
                    added+=int(ok); skipped+=int(not ok)
                except Exception as e: errors.append(f"{name}: {e}")
            flash(f"Import complete: {added} new records, {skipped} existing/duplicate records skipped. "+("Errors: "+" | ".join(errors[:4]) if errors else ""))
            return redirect(url_for("library"))
        q=request.args.get("q",""); rows=db.articles(q)
        body="""<section class="card"><h2>Import article files and reference exports</h2><form method="post" enctype="multipart/form-data">
        <label>Select multiple PDF, DOCX, TXT, RIS, or CSV files</label><input type="file" name="files" multiple accept=".pdf,.docx,.txt,.ris,.csv">
        <label>Reviewer / actor</label><input name="reviewer" value="Researcher"><button>Import selected files</button></form>
        <p class="muted small">PDF/DOCX/TXT text extraction uses local processing. Scanned PDFs may need OCR. Bibliographic metadata is heuristic and should be checked.</p></section>
        <section class="card"><h2>Searchable article library ({{rows|length}} shown)</h2><form method="get"><input name="q" value="{{q}}" placeholder="Search title, authors, DOI, journal, abstract, keywords, or path"><button>Search</button> <a class="button secondary" href="/library">Clear</a></form>
        <div class="table-wrap"><table><thead><tr><th>ID</th><th>Year</th><th>Title / authors</th><th>DOI</th><th>Decision</th><th>Action</th></tr></thead><tbody>
        {% for a in rows %}<tr><td>{{a.id}}</td><td>{{a.year or ""}}</td><td><b>{{a.title}}</b><br><span class="muted">{{a.authors}}</span><br><span class="small muted">{{a.file_path}}</span></td><td>{{a.doi}}</td><td>{{a.decision or "Not screened"}}</td><td><a href="/article/{{a.id}}">Inspect</a></td></tr>{% else %}<tr><td colspan="6">No articles yet. Import files above.</td></tr>{% endfor %}
        </tbody></table></div><p><a class="button" href="/export/library.csv">Export library CSV</a></p></section>"""
        return page(body,rows=rows,q=q)

    @app.get("/article/<int:aid>")
    def article_detail(aid):
        a=db.get_article(aid)
        if not a: return "Article not found",404
        body="""<section class="card"><h2>{{a.title}}</h2><p>{{a.authors}} · {{a.year or "Year unknown"}} · {{a.journal}}</p><p>DOI: {{a.doi or "Not found"}}</p><p>File: {{a.file_path}}</p>
        <h3>Abstract</h3><p>{{a.abstract or "No abstract extracted"}}</p><h3>Metadata review</h3><pre>{{a.pdf_metadata}}</pre>
        <form method="post" action="/crossref/{{a.id}}"><button>Look up by DOI in Crossref</button><button class="secondary" name="mode" value="title">Search Crossref by title</button></form>
        {% if crossref_results %}<h3>Crossref title matches — compare before applying</h3>{% for r in crossref_results %}<div class="ev-card"><b>{{r.title}}</b><br>{{r.authors}} · {{r.year or "Year unknown"}} · {{r.journal}}<br>DOI: {{r.doi}}<form method="post" action="/crossref/{{a.id}}"><input type="hidden" name="apply_doi" value="{{r.doi}}"><button>Apply this match</button></form></div>{% endfor %}{% endif %}
        <h3>Page-aware extracted text</h3><div class="article-text">{{a.full_text[:12000]}}</div>
        <a class="button secondary" href="/library">Back to library</a><a class="button" href="/review/{{a.id}}">Open side-by-side review</a></section>"""
        return page(body,a=a,crossref_results=[])

    @app.post("/crossref/<int:aid>")
    def crossref_lookup(aid):
        a=db.get_article(aid)
        if not a: return "Article not found",404
        actor=request.form.get("reviewer","Researcher").strip() or "Researcher"
        try:
            if request.form.get("apply_doi"):
                doi=normalize_doi(request.form.get("apply_doi"))
                result=crossref.lookup_doi(doi)
                db.update_article_metadata(aid,result,actor)
                flash("Crossref metadata applied. Please verify every field against the article PDF.")
                return redirect(url_for("article_detail",aid=aid))
            if request.form.get("mode")=="title":
                results=crossref.search_title(a.get("title",""))
                # Show candidates on the article detail page; no metadata is silently applied.
                body="""<section class="card"><h2>Crossref title-search candidates</h2><p>Compare the title, authors, year, journal, and DOI with the PDF before applying a match.</p>
                {% for r in results %}<div class="ev-card"><b>{{r.title}}</b><br>{{r.authors}} · {{r.year or "Year unknown"}} · {{r.journal}}<br>DOI: {{r.doi or "Not supplied"}}<form method="post" action="/crossref/{{a.id}}"><input type="hidden" name="apply_doi" value="{{r.doi}}"><button {% if not r.doi %}disabled{% endif %}>Verify DOI and apply metadata</button></form></div>{% else %}<p>No candidates returned.</p>{% endfor %}<a class="button secondary" href="/article/{{a.id}}">Back to article</a></section>"""
                return page(body,a=a,results=results)
            result=crossref.lookup_doi(a.get("doi",""))
            # Explicit DOI lookup is preview-only first; application is a separate action.
            body="""<section class="card"><h2>Crossref metadata match</h2><p>Crossref metadata is a useful bibliographic source, but it can be incomplete or incorrect. Compare it with the publisher PDF before applying.</p>
            <div class="ev-card"><b>{{r.title}}</b><br>{{r.authors}} · {{r.year or "Year unknown"}}<br>{{r.journal}}<br>DOI: {{r.doi}}<p>{{r.abstract}}</p>
            <form method="post" action="/crossref/{{a.id}}"><input type="hidden" name="apply_doi" value="{{r.doi}}"><button>Apply Crossref metadata</button></form></div><a class="button secondary" href="/article/{{a.id}}">Back</a></section>"""
            return page(body,a=a,r=result)
        except Exception as e:
            flash("Crossref lookup failed: "+str(e))
            return redirect(url_for("article_detail",aid=aid))

    @app.route("/duplicates",methods=["GET","POST"])
    def duplicates():
        groups={}; scanned=0
        if request.method=="POST":
            folder=request.form.get("folder","").strip()
            root=Path(folder).expanduser()
            if not root.is_dir(): flash("Folder path not found. Enter a valid local folder path on the computer running ResearchMate AI.")
            else:
                hashes=defaultdict(list); scanned=0; errors=0
                for p in root.rglob("*"):
                    if p.is_file():
                        try: hashes[file_hash(str(p))].append(str(p)); scanned+=1
                        except Exception: errors+=1
                groups={h:ps for h,ps in hashes.items() if len(ps)>1}
                db.save_scan(str(root),scanned,len(groups))
                flash(f"Scanned {scanned} files; {len(groups)} exact duplicate groups found; {errors} unreadable files. Nothing was deleted.")
        body="""<section class="card"><h2>Exact duplicate file scan</h2><p>Enter a folder path on the machine running the local app. Matching uses SHA-256 byte identity. It does not delete files.</p>
        <form method="post"><label>Folder path (example: C:\\Research\\Articles)</label><input name="folder" placeholder="C:\\Research\\Articles" required><button>Scan folder</button></form></section>
        {% if groups %}<section class="card"><h2>Duplicate groups ({{groups|length}})</h2><div class="table-wrap"><table><tr><th>SHA-256</th><th>Copies</th><th>Paths</th></tr>{% for h,ps in groups.items() %}<tr><td>{{h}}</td><td>{{ps|length}}</td><td>{% for p in ps %}{{p}}<br>{% endfor %}</td></tr>{% endfor %}</table></div></section>{% endif %}"""
        return page(body,groups=groups)

    @app.route("/screening",methods=["GET","POST"])
    def screening():
        if request.method=="POST":
            actor=request.form.get("actor") or "Researcher"; mode=request.form.get("mode","tfidf")
            p=criteria(); rows=db.articles(); count=0
            for a in rows:
                # Preserve a final human decision; only re-run non-final or unscreened records.
                if a.get("is_final"): continue
                res=screen(a,p,mode)
                db.save_screening(a["id"],res,reviewer=actor,notes="Automated suggestion; human review required",final=False,actor=actor)
                count+=1
            flash(f"Screening suggestions created for {count} records. Final human decisions were preserved.")
            return redirect(url_for("screening"))
        rows=db.screening_rows()
        body="""<section class="card"><h2>Run assisted screening</h2><p>Keyword matching captures evidence snippets. TF-IDF is lexical similarity, not true semantic understanding. Optional sentence-transformers uses a local embedding model and may download model files the first time it runs.</p>
        <form method="post"><div class="row"><div><label>Similarity mode</label><select name="mode"><option value="tfidf">TF-IDF lexical similarity (default)</option><option value="embeddings">Local sentence-transformer embeddings, fallback to TF-IDF</option><option value="none">No similarity score</option></select></div><div><label>Reviewer / actor</label><input name="actor" value="Researcher"></div></div><button>Run screening suggestions</button></form>
        <p class="muted small">The engine does not automatically assert peer review. Even term-matching records remain Uncertain until a human verifies topic, publication type, and methodology.</p></section>
        <section class="card"><h2>Screening records</h2><p><a class="button" href="/export/screening.csv">Export screening CSV</a></p><div class="table-wrap"><table><tr><th>Article</th><th>Decision</th><th>Score / method</th><th>Reason</th><th>Reviewer / final</th><th>Action</th></tr>
        {% for a in rows %}<tr><td><b>{{a.title}}</b><br>{{a.year or ""}} · {{a.authors}}</td><td><span class="pill {% if a.decision=='Include' %}include{% elif a.decision=='Exclude' %}exclude{% else %}uncertain{% endif %}">{{a.decision or "Not screened"}}</span></td><td>{{a.score if a.score is not none else ""}}<br><span class="small">{{a.method}}</span></td><td>{{a.primary_reason or ""}}<details><summary>Evidence ({{(a.evidence_json or "[]")|length}} chars)</summary><pre>{{a.evidence_json}}</pre><pre>{{a.criterion_results}}</pre></details></td><td>{{a.reviewer or ""}}<br>{{"Final" if a.is_final else "Suggestion / non-final"}}<br>{{a.reviewed_at or ""}}</td><td><a href="/review/{{a.id}}">Review / decide</a></td></tr>{% else %}<tr><td colspan="6">No articles. Import files first.</td></tr>{% endfor %}</table></div></section>"""
        return page(body,rows=rows)

    @app.route("/review/<int:aid>",methods=["GET","POST"])
    def review(aid):
        a=db.get_article(aid)
        if not a: return "Article not found",404
        old=db.screening_rows(); s=next((x for x in old if x["id"]==aid),{})
        if request.method=="POST":
            decision=request.form.get("decision","Uncertain")
            if decision not in {"Include","Exclude","Uncertain"}: decision="Uncertain"
            reason=request.form.get("reason","").strip(); reviewer=request.form.get("reviewer","Researcher").strip() or "Researcher"
            notes=request.form.get("notes","").strip(); final=bool(request.form.get("final"))
            res={"decision":decision,"reason":reason,"score":s.get("score"),"method":"human review",
                 "criterion_results":json.loads(s.get("criterion_results") or "{}"),
                 "evidence":json.loads(s.get("evidence_json") or "[]")}
            db.save_screening(aid,res,reviewer,notes,final,reviewer)
            flash("Human review decision saved and audit trail updated.")
            return redirect(url_for("screening"))
        try: evidence=json.loads(s.get("evidence_json") or "[]")
        except Exception: evidence=[]
        try: criterion_results=json.loads(s.get("criterion_results") or "{}")
        except Exception: criterion_results={}
        # Build a safe, page-aware text pane. Page markers were added during PDF extraction.
        full_text=a.get("full_text") or ""
        body="""<section class="card"><h2>Side-by-side article review</h2><h3>{{a.title}}</h3><p>{{a.authors}} · {{a.year or "Year unknown"}} · DOI {{a.doi or "not identified"}}</p>
        <div class="review-layout"><section class="article-pane"><h3>Article text and page markers</h3><p class="muted small">PDF pages are marked as Page N. Select an evidence card to jump to the corresponding page marker when available.</p>
        <div class="article-text" id="articleText">{{full_text[:200000]}}</div></section>
        <section class="decision-pane"><div class="card review-controls"><h3>Screening evidence</h3>
        {% for ev in evidence %}<div class="ev-card"><span class="pill">{{ev.criterion or "Evidence"}}</span> <b>{{ev.term}}</b>
        <div class="small muted">{% if ev.page %}PDF page {{ev.page}} · {% endif %}Characters {{ev.char_start}}–{{ev.char_end}}</div>
        <blockquote>{{ev.quote}}</blockquote><button type="button" class="secondary jump-evidence" data-page="{{ev.page or ''}}" data-start="{{ev.char_start or 0}}">Locate in text</button></div>{% else %}<p>No term evidence captured yet. Run screening suggestions first or inspect the article text manually.</p>{% endfor %}
        <h3>Eligibility rationale</h3><p><b>Suggested reason:</b> {{s.primary_reason or "No screening suggestion yet"}}</p><pre>{{criterion_results}}</pre>
        <form method="post"><div class="row"><div><label>Final decision</label><select name="decision">{% for d in ["Include","Exclude","Uncertain"] %}<option {% if s.decision==d %}selected{% endif %}>{{d}}</option>{% endfor %}</select></div><div><label>Reviewer name</label><input name="reviewer" value="{{s.reviewer or 'Researcher'}}"></div></div>
        <label>Primary reason / exclusion code</label><input name="reason" value="{{s.primary_reason or ''}}" placeholder="e.g. EX-03 — ineligible methodology; start with FT- for full-text exclusions">
        <label>Reviewer notes and supporting rationale</label><textarea name="notes">{{s.reviewer_notes or ""}}</textarea>
        <label><input style="width:auto" type="checkbox" name="final" value="yes" {% if s.is_final %}checked{% endif %}> Mark decision as final after human verification</label>
        <button>Save review decision</button> <a class="button secondary" href="/screening">Cancel</a></form>
        <form method="post" action="/crossref/{{a.id}}"><button class="secondary">Check DOI with Crossref</button><button class="secondary" name="mode" value="title">Search Crossref by title</button></form>
        </div></section></div></section>
        <script>
        document.querySelectorAll('.jump-evidence').forEach(btn=>btn.addEventListener('click',()=>{
          const pane=document.getElementById('articleText'); const page=btn.dataset.page;
          if(page){const marker='[[PAGE:'+page+']]';const idx=pane.textContent.indexOf(marker);if(idx>=0){pane.scrollTop=Math.max(0,idx/Math.max(1,pane.textContent.length)*pane.scrollHeight-80);return;}}
          const start=Number(btn.dataset.start||0);pane.scrollTop=Math.max(0,start/Math.max(1,pane.textContent.length)*pane.scrollHeight-80);
        }));
        </script>"""
        return page(body,a=a,s=s,evidence=evidence,criterion_results=criterion_results,full_text=full_text)

    @app.get("/audit")
    def audit():
        rows=db.audit_rows(1000)
        body="""<section class="card"><h2>Reviewer audit trail</h2><p class="muted">Latest 1,000 events. Decision changes are appended rather than overwriting history.</p>
        <div class="table-wrap"><table><tr><th>When</th><th>Actor</th><th>Entity</th><th>Action</th><th>Details</th><th>Old / new values</th></tr>
        {% for r in rows %}<tr><td>{{r.created_at}}</td><td>{{r.actor}}</td><td>{{r.entity_type}} #{{r.entity_id}}</td><td>{{r.action}}</td><td>{{r.details}}</td><td><details><summary>Show</summary><b>Old</b><pre>{{r.old_value}}</pre><b>New</b><pre>{{r.new_value}}</pre></details></td></tr>{% endfor %}</table></div></section>"""
        return page(body,rows=rows)

    @app.post("/project/template")
    def project_template():
        d=dict(R_TEMPLATE); db.save_project(d,"Researcher"); flash("UAV crop-health review template loaded; edit it before use."); return redirect(url_for("project_page"))

    def _state():
        p=criteria(); inc=db.included_articles(); rows=db.screening_rows()
        return p,inc,R.prisma(p,rows,db.duplicate_skip_count())

    @app.get("/results")
    def results_page():
        p,inc,c=_state()
        body="""<section class="card"><h2>Output results — included articles</h2>
        <p class="muted">Built only from records with a <b>final human Include</b> decision, under the current project criteria. Title/abstract exclusions and full-text exclusions (reason code starting <code>FT</code>) are counted separately.</p>
        <p><a class="button" href="/results/report.docx">Output results (Word)</a><a class="button" href="/results/extraction.csv">Extraction sheet (CSV)</a><a class="button" href="/results/references.ris">References (RIS)</a><a class="button" href="/results/source_pack.zip">Download source pack (ZIP)</a></p></section>
        <section class="card"><h2>PRISMA 2020 planning counts</h2><div class="grid">
        <div class="metric"><span class="muted">Identified (databases)</span><strong>{{c.identified if c.identified is not none else "___"}}</strong></div>
        <div class="metric"><span class="muted">Duplicates removed</span><strong>{{c.duplicates_removed if c.duplicates_removed is not none else "___"}}</strong></div>
        <div class="metric"><span class="muted">Unique records screened</span><strong>{{c.library}}</strong></div>
        <div class="metric"><span class="muted">Excluded title/abstract</span><strong>{{c.excluded_title_abstract}}</strong></div>
        <div class="metric"><span class="muted">Full texts assessed</span><strong>{{c.full_text_assessed}}</strong></div>
        <div class="metric"><span class="muted">Full-text exclusions</span><strong>{{c.excluded_full_text}}</strong></div>
        <div class="metric"><span class="muted">Included</span><strong>{{c.included}}</strong></div>
        <div class="metric"><span class="muted">Not yet finally decided</span><strong>{{c.unresolved}}</strong></div></div>
        <p class="muted small">Identified counts come from the databases list on the Project page. Duplicates removed = identified minus unique library records (this app also skipped {{c.dup_in_app}} duplicate imports). Use the official PRISMA template for the manuscript.</p>
        {% if c.reasons %}<h3>Exclusion reasons</h3><ul>{% for k,v in c.reasons.items() %}<li>{{k}}: {{v}}</li>{% endfor %}</ul>{% endif %}</section>
        <section class="card"><h2>Included articles ({{inc|length}})</h2><div class="table-wrap"><table><tr><th>#</th><th>Reference</th><th>Reviewer</th></tr>
        {% for a in inc %}<tr><td>{{loop.index}}</td><td>{{R.reference(a)}}</td><td>{{a.reviewer}}</td></tr>{% else %}<tr><td colspan="3">No final Include decisions yet. Review articles and tick “Mark decision as final”.</td></tr>{% endfor %}</table></div></section>"""
        return page(body,p=p,inc=inc,c=c,R=R)

    @app.get("/results/<kind>")
    def results_download(kind):
        p,inc,c=_state()
        from tempfile import NamedTemporaryFile, gettempdir
        if kind=="extraction.csv":
            return Response(R.csv_bytes(R.extraction_rows(inc)),mimetype="text/csv",headers={"Content-Disposition":"attachment; filename=extraction_sheet.csv"})
        if kind=="references.ris":
            return Response(R.ris_bytes(inc),mimetype="application/x-research-info-systems",headers={"Content-Disposition":"attachment; filename=included_references.ris"})
        if kind=="report.docx":
            t=NamedTemporaryFile(suffix=".docx",delete=False); t.close(); R.results_docx(t.name,p,c,inc)
            return send_file(t.name,as_attachment=True,download_name="ResearchMate_Results_Included_Articles.docx")
        if kind=="source_pack.zip":
            secs=_sections(p,inc,c)
            data=R.source_pack(p,c,inc,secs,gettempdir())
            return Response(data,mimetype="application/zip",headers={"Content-Disposition":"attachment; filename=ResearchMate_Source_Pack.zip"})
        return "Not found",404

    def _sections(p,inc,c):
        drafts=db.get_drafts(); gen=R.write_sections(p,inc,c)
        return {n:(drafts[n]["body"] if n in drafts and drafts[n]["edited"] else gen[n]) for n in R.SECTIONS}

    @app.get("/writer")
    def writer():
        p,inc,c=_state(); secs=_sections(p,inc,c); drafts=db.get_drafts()
        body="""<section class="card"><h2>Project information writer — referenced paragraphs</h2>
        <p class="muted">Writes the nine proposal sections locally. Citations [n] point only to records with a final Include decision, and the reference list below is built from your library, not generated. Cited passages are extracted from abstracts — rewrite and verify against the full articles. Sections you edit and save are kept; others refresh from current data.</p>
        <p>Final included records: <b>{{inc|length}}</b> · <a class="button secondary" href="/results">Output results</a>
        <a class="button" href="/writer/export.docx">Download Word (.docx)</a><a class="button secondary" href="/writer/export.md">Download Markdown</a><a class="button secondary" href="/results/source_pack.zip">Download source pack (ZIP)</a></p>
        <form method="post" action="/writer/save">
        {% for n in names %}<h3>{{n}}{% if drafts.get(n) and drafts[n].edited %} <span class="pill">edited</span>{% endif %}</h3><textarea name="s{{loop.index0}}" style="min-height:{{ 220 if loop.index0 in (0,1,4,5) else 120 }}px">{{secs[n]}}</textarea>{% endfor %}
        <h3>9. References</h3><div class="evidence">{{refs}}</div>
        <button>Save edits</button></form>
        <form method="post" action="/writer/reset" data-confirm="Discard saved edits and regenerate all sections from current data?"><button class="secondary">Regenerate all sections</button></form></section>"""
        return page(body,inc=inc,names=R.SECTIONS,secs=secs,drafts=drafts,refs=R.references_text(inc))

    @app.post("/writer/save")
    def writer_save():
        p,inc,c=_state(); gen=R.write_sections(p,inc,c)
        for i,n in enumerate(R.SECTIONS):
            txt=request.form.get(f"s{i}","").strip()
            if txt and txt!=gen[n].strip(): db.save_draft(n,txt,True)
        flash("Edits saved."); return redirect(url_for("writer"))

    @app.post("/writer/reset")
    def writer_reset():
        with db.connect() as cn: cn.execute("DELETE FROM drafts")
        flash("Sections regenerated from current data."); return redirect(url_for("writer"))

    @app.get("/writer/export.<ext>")
    def writer_export(ext):
        p,inc,c=_state(); secs=_sections(p,inc,c)
        if ext=="md": return Response(R.proposal_md(p,secs,inc),mimetype="text/markdown",headers={"Content-Disposition":"attachment; filename=project_information.md"})
        if ext=="docx":
            from tempfile import NamedTemporaryFile
            t=NamedTemporaryFile(suffix=".docx",delete=False); t.close(); R.proposal_docx(t.name,p,secs,inc)
            return send_file(t.name,as_attachment=True,download_name="ResearchMate_Project_Information.docx")
        return "Not found",404

    @app.get("/proposal")
    def proposal(): return redirect(url_for("writer"))

    @app.post("/proposal/export")
    def proposal_export(): return redirect("/writer/export.docx")

    @app.get("/export/<kind>")
    def export(kind):
        if kind not in {"library.csv","screening.csv"}: return "Not found",404
        rows=db.articles() if kind=="library.csv" else db.screening_rows()
        output=io.StringIO(); fields=list(rows[0].keys()) if rows else ["id","title","year","decision","primary_reason"]
        writer=csv.DictWriter(output,fieldnames=fields,extrasaction="ignore"); writer.writeheader()
        for r in rows: writer.writerow(r)
        from flask import Response
        return Response(output.getvalue(),mimetype="text/csv",headers={"Content-Disposition":f"attachment; filename={kind}"})

    @app.get("/api/articles")
    def api_articles():
        q=request.args.get("q","")
        return jsonify(db.articles(q))
    return app
