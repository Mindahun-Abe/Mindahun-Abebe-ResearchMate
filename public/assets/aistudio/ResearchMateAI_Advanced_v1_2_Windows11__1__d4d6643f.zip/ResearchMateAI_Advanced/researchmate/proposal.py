
from datetime import date
def build_proposal(project,articles):
 title=project.get("review_title") or project.get("name") or "Research Proposal"
 included=[a for a in articles if (a.get("decision") or "").lower()=="include" and a.get("is_final")]
 refs=[]
 for a in included:
  doi=a.get("doi") or ""
  refs.append(f"{a.get('authors') or '[Authors to verify]'} ({a.get('year') or 'n.d.'}). {a.get('title') or '[Title missing]'}. {a.get('journal') or ''}. "+(f"https://doi.org/{doi}" if doi else "[DOI not recorded]"))
 return {"title":title,"sections":[
 ("Project information",f"Discipline: {project.get('discipline') or '[Specify]'}\nStudy area/population: {project.get('study_area') or '[Specify]'}\nPrepared: {date.today().isoformat()}"),
 ("1. Background and rationale","[Write a source-grounded overview of the problem, its importance, current knowledge, and context. Link factual claims to verified sources.]"),
 ("2. Problem statement","[Describe the specific problem and evidence demonstrating its significance. Separate established findings from assumptions.]"),
 ("3. Research aim",f"To investigate {title}."),
 ("4. Objectives","[Define a general objective and specific, measurable objectives aligned with the research question and available data.]"),
 ("5. Research questions",project.get("research_question") or "[Specify research questions.]"),
 ("6. Literature review and research gap","[Synthesize included studies by themes, methods, findings, and limitations. State gaps only when supported by a documented search and evidence matrix.]"),
 ("7. Methodology","[Design and setting]\n[Data sources and sampling or eligibility criteria]\n[Data collection and preparation]\n[Analysis methods and software]\n[Validation / quality assurance]\n[Ethics, data management, limitations]\n[Adapt to the discipline; this is a scaffold.]"),
 ("8. Expected outputs and significance","[Describe realistic deliverables and beneficiaries. Do not state results before analysis.]"),
 ("9. Work plan","[Add phases, milestones, and dates.]"),
 ("10. References marked Include and final","\n".join(f"{i+1}. {r}" for i,r in enumerate(refs)) if refs else "[No records have both a final Include decision and verified reference metadata.]"),
 ("Verification note",f"Generated {date.today().isoformat()}; included references: {len(refs)}. Verify every source, claim, method, and citation before submission.")
 ]}
def export_docx(proposal,path):
 from docx import Document
 from docx.shared import Inches,Pt
 doc=Document(); sec=doc.sections[0]; sec.top_margin=Inches(.8); sec.bottom_margin=Inches(.8)
 doc.add_heading(proposal["title"],0)
 for h,b in proposal["sections"]:
  doc.add_heading(h,level=1)
  for line in b.splitlines():
   if line.strip(): doc.add_paragraph(line)
 for style in doc.styles:
  if style.type==1: style.font.name="Aptos"; style.font.size=Pt(10.5)
 doc.save(path)
