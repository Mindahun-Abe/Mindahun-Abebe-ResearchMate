"""Results output, PRISMA counts, referenced paragraph writer and exports (all local, no cloud AI)."""
import re, io, csv, zipfile
from datetime import date
from .screening import split_terms

SECTIONS = ["1. Background and rationale", "2. Problem statement", "3. Research aim and objectives",
            "4. Research questions", "5. Literature review and research gap", "6. Methodology",
            "7. Expected outputs", "8. Work plan"]

# Evidence themes taken from the systematic-review guide (used for literature synthesis and gap counts).
THEMES = {
    "UAV platforms and sensors": ["multispectral", "thermal", "hyperspectral", "rgb", "lidar", "multirotor", "fixed-wing", "sensor"],
    "Flight planning and spatial resolution": ["flight", "altitude", "gsd", "ground sampling", "overlap", "resolution", "orthomosaic"],
    "Analytical methods": ["machine learning", "deep learning", "random forest", "cnn", "neural", "vegetation index", "ndvi", "classification", "regression", "fusion"],
    "Real-time operation and latency": ["real-time", "real time", "near-real", "latency", "onboard", "edge", "processing time"],
    "Validation, uncertainty and transferability": ["validation", "independent", "transfer", "generaliz", "generalis", "uncertainty", "cross-season", "ground truth", "ground-truth"],
}

def first_author(a):
    s = (a.get("authors") or "").split(";")[0].strip()
    if not s: return "Anon."
    return s.split(",")[0].strip() if "," in s else s.split()[-1]

def short_cite(a):
    n = len([x for x in (a.get("authors") or "").split(";") if x.strip()])
    return f"{first_author(a)}{' et al.' if n > 2 else ''} ({a.get('year') or 'n.d.'})"

def reference(a):
    doi = (a.get("doi") or "").strip()
    return (f"{a.get('authors') or '[Authors to verify]'} ({a.get('year') or 'n.d.'}). {a.get('title') or '[Title missing]'}. "
            f"{(a.get('journal') or '').strip()}. " + (f"https://doi.org/{doi}" if doi else "[DOI not recorded]")).replace(" .", ".").replace("..", ".")

def parse_db_counts(text):
    out = []
    for line in (text or "").splitlines():
        p = [x.strip() for x in line.split("|")]
        if p and p[0]:
            n = re.sub(r"\D", "", p[2]) if len(p) > 2 else ""
            out.append({"name": p[0], "date": p[1] if len(p) > 1 else "", "n": int(n) if n else None})
    return out

def prisma(project, all_rows, dup_skipped):
    """Planning counts computed only from recorded data. Full-text exclusions use reason codes starting 'FT'."""
    dbs = parse_db_counts(project.get("db_counts"))
    ident = sum(d["n"] or 0 for d in dbs) if any(d["n"] for d in dbs) else None
    final = [a for a in all_rows if a.get("is_final")]
    inc = [a for a in final if a.get("decision") == "Include"]
    exc = [a for a in final if a.get("decision") == "Exclude"]
    ft = [a for a in exc if (a.get("primary_reason") or "").strip().upper().startswith("FT")]
    ta = [a for a in exc if a not in ft]
    reasons = {}
    for a in exc:
        k = (a.get("primary_reason") or "No reason recorded").strip()
        reasons[k] = reasons.get(k, 0) + 1
    lib = len(all_rows)
    return {"databases": dbs, "identified": ident, "dup_in_app": dup_skipped, "library": lib,
            "duplicates_removed": (ident - lib) if ident is not None and ident >= lib else None,
            "excluded_title_abstract": len(ta), "excluded_full_text": len(ft), "included": len(inc),
            "full_text_assessed": len(inc) + len(ft), "unresolved": lib - len(final), "reasons": reasons}

def _sentences(text):
    t = re.sub(r"\s+", " ", text or "").strip()
    return [s.strip() for s in re.split(r"(?<=[.!?])\s+(?=[A-Z0-9])", t) if 50 <= len(s) <= 420]

def _score(sentence, terms):
    low = sentence.lower()
    return sum(1 for t in terms if t and t in low)

def _terms(project, extra=()):
    base = split_terms(project.get("required_terms")) + split_terms(project.get("any_terms")) + list(extra)
    base += re.findall(r"[a-zA-Z\-]{5,}", project.get("review_title") or "")
    return list({t.lower() for t in base})

def theme_matches(included):
    res = {}
    for name, kws in THEMES.items():
        hit = []
        for i, a in enumerate(included):
            text = " ".join(str(a.get(k) or "") for k in ("title", "abstract", "keywords")).lower()
            if any(k in text for k in kws): hit.append(i)
        res[name] = hit
    return res

def _best_sentence(a, terms, kws=()):
    """Best abstract sentence; when theme keywords are given, the sentence must contain one of them."""
    best, sc = None, -1
    for s in _sentences(a.get("abstract")):
        k = _score(s, list(kws))
        if kws and k == 0: continue
        v = _score(s, terms) + 2 * k
        if v > sc: best, sc = s, v
    return best

def write_sections(project, included, counts):
    """Deterministic, citation-grounded draft. Cited sentences are extracted from abstracts of final-included records."""
    N = len(included)
    cite = lambda idxs: " ".join(f"[{i+1}]" for i in idxs)
    terms = _terms(project)
    title = project.get("review_title") or project.get("name") or "the review topic"
    out = {}
    # 1 Background
    ranked = sorted(((max([_score(s, terms) for s in _sentences(a.get("abstract"))] or [0]), i) for i, a in enumerate(included)), reverse=True)[:4]
    bits = []
    for _, i in ranked:
        s = _best_sentence(included[i], terms)
        if s: bits.append(f"{short_cite(included[i])} [{i+1}]: \u201c{s}\u201d")
    out[SECTIONS[0]] = (f"This project addresses {title}. " + (" ".join(bits) if bits else "No abstract evidence is available yet from final-included records; import abstracts and finalise Include decisions.")
        + "\n\nThe passages above are extracted from abstracts of records with a final human Include decision and must be checked against the full articles before use.")
    # 2 Problem statement
    prob = []
    for i, a in enumerate(included):
        for s in _sentences(a.get("abstract")):
            if re.search(r"\b(however|limited|challenge|lack|remain|gap|difficult|constraint|unclear|still)\b", s, re.I) and _score(s, terms) > 0:
                prob.append((i, s)); break
    pr = " ".join(f"{short_cite(included[i])} [{i+1}]: \u201c{s}\u201d" for i, s in prob[:4])
    out[SECTIONS[1]] = (pr or "No limitation or gap statements were detected in the included abstracts; state the problem from your own verified sources.") + \
        "\n\nResearcher input needed: describe the specific problem and why it matters, separating established findings from assumptions."
    # 3 Aim and objectives
    obj = [l.strip() for l in (project.get("objectives") or "").splitlines() if l.strip()]
    out[SECTIONS[2]] = f"Aim: To systematically review and synthesise evidence on {title}.\n\nObjectives:\n" + ("\n".join(obj) if obj else "[Add objectives on the Project page.]")
    # 4 Research questions
    rq = [l.strip() for l in (project.get("research_question") or "").splitlines() if l.strip()]
    out[SECTIONS[3]] = "\n".join(rq) if rq else "[Add research questions on the Project page.]"
    # 5 Literature review and gap
    tm = theme_matches(included); paras = []
    for name, idxs in tm.items():
        if not idxs:
            paras.append(f"{name}: none of the {N} included records mention this theme in the title, abstract or keywords."); continue
        kws = THEMES[name]; ex = []
        for i in idxs[:3]:
            s = _best_sentence(included[i], terms, kws)
            if s: ex.append(f"{short_cite(included[i])} [{i+1}]: \u201c{s}\u201d")
        paras.append(f"{name} ({len(idxs)} of {N} records; {cite(idxs[:8])}{'…' if len(idxs) > 8 else ''}). " + " ".join(ex))
    weak = [n for n, ix in tm.items() if len(ix) <= max(1, N // 5)]
    gap = ("Evidence gap (counted from title/abstract/keyword matching, not full-text reading): " +
           (", ".join(f"{n} ({len(tm[n])} of {N})" for n in weak) + " are the least represented themes." if N and weak else "no theme is markedly under-represented in the included records.")
           if N else "No included records yet, so no gap can be stated.")
    out[SECTIONS[4]] = "\n\n".join(paras) + "\n\n" + gap + "\nState any claim of novelty only after a documented search and evidence matrix."
    # 6 Methodology (from recorded project data)
    dbs = counts["databases"]
    dbtxt = "; ".join(f"{d['name']}{' (searched ' + d['date'] + ')' if d['date'] else ''}{', n = ' + str(d['n']) if d['n'] is not None else ''}" for d in dbs) or "[databases to be recorded]"
    req, anyt, exc = split_terms(project.get("required_terms")), split_terms(project.get("any_terms")), split_terms(project.get("excluded_terms"))
    out[SECTIONS[5]] = (
        "Design and reporting: a systematic review reported according to PRISMA 2020. Databases and sources: " + dbtxt + ".\n\n"
        "Search strategy: " + (project.get("search_strategy") or "[add Boolean search string]") + "\n\n"
        f"Eligibility: publication years {project.get('year_start')}\u2013{project.get('year_end')}; document types: {project.get('allowed_types') or '[specify]'}. "
        + (f"Required terms: {', '.join(req)}. " if req else "") + (f"At least one of: {', '.join(anyt)}. " if anyt else "")
        + (f"Flagged for review: {', '.join(exc)}. " if exc else "") + "Term matching only suggests a decision; every decision is made by a human reviewer and logged in the audit trail.\n\n"
        f"Screening and selection so far: {counts['library']} unique records in the library"
        + (f" from {counts['identified']} identified" if counts['identified'] is not None else "") + f"; {counts['excluded_title_abstract']} excluded at title/abstract; {counts['full_text_assessed']} assessed at full text; {counts['included']} included. "
        "Data extraction: one row per included study (context, UAV/sensor, flight planning, processing, ground truth, models, real-time latency). "
        "Critical appraisal: a predefined technical checklist (design, sensor/acquisition, validation including spatial leakage, operational readiness); incomplete reporting is classed as missing information rather than automatic exclusion. "
        "Synthesis: structured narrative synthesis with descriptive statistics; unlike performance metrics (accuracy, R\u00b2, RMSE) are not pooled.")
    # 7 Expected outputs
    out[SECTIONS[6]] = ("Evidence tables (search strategy, eligibility, study characteristics, sensor specifications, flight-planning parameters, validation metrics, real-time latency, quality appraisal, research gaps); "
        "a PRISMA 2020 flow diagram with actual counts; a monitoring-workflow figure (flight planning \u2192 sensing \u2192 processing \u2192 stress mapping \u2192 decision support); "
        "an evidence-synthesis framework; and a practical-readiness framework for near-real-time decisions. Results are not stated before analysis.")
    # 8 Work plan
    out[SECTIONS[7]] = (project.get("work_plan") or
        "Phase 1: pilot search in two databases and screen 30\u201350 records; refine protocol. Phase 2: full searches (each saved separately) and de-duplication. Phase 3: title/abstract screening. "
        "Phase 4: full-text assessment with exclusion reasons. Phase 5: data extraction and critical appraisal. Phase 6: synthesis. Phase 7: writing and PRISMA reporting. [Add dates and milestones.]")
    return out

def references_text(included):
    return "\n".join(f"[{i+1}] {reference(a)}" for i, a in enumerate(included)) or "[No records with a final Include decision.]"

def extraction_rows(included):
    head = ["Study ID", "Authors", "Year", "Title", "Journal", "DOI", "Country/site", "Crop & growth stage", "Crop-health problem", "Platform",
            "Sensor & bands", "Altitude (m)", "GSD (cm/px)", "Overlap (%)", "Flight time/weather", "Processing software", "Indices/features",
            "Ground truth", "Algorithm", "Metric(s)", "Validation level", "Uncertainty reported", "Transferability tested", "Acquisition time",
            "Transfer time", "Processing time", "Total latency", "Processing location", "Decision output", "Appraisal notes", "Reviewer", "Final decision notes"]
    rows = [head]
    for i, a in enumerate(included):
        r = [f"S{i+1:03d}", a.get("authors"), a.get("year"), a.get("title"), a.get("journal"), a.get("doi")] + [""] * 24 + [a.get("reviewer"), a.get("reviewer_notes")]
        rows.append(["" if v is None else v for v in r])
    return rows

def csv_bytes(rows):
    buf = io.StringIO(); csv.writer(buf).writerows(rows); return ("\ufeff" + buf.getvalue()).encode("utf-8")

def ris_bytes(included):
    out = []
    for a in included:
        out.append("TY  - JOUR")
        for au in [x.strip() for x in (a.get("authors") or "").split(";") if x.strip()]: out.append(f"AU  - {au}")
        out += [f"TI  - {a.get('title') or ''}", f"PY  - {a.get('year') or ''}", f"JO  - {a.get('journal') or ''}"]
        if a.get("doi"): out.append(f"DO  - {a['doi']}")
        if a.get("abstract"): out.append(f"AB  - {a['abstract']}")
        out.append("ER  - ")
    return ("\r\n".join(out) + "\r\n").encode("utf-8")

def results_docx(path, project, counts, included):
    from docx import Document
    from docx.shared import Pt
    d = Document(); d.add_heading("Results: included articles", 0)
    d.add_paragraph(f"{project.get('review_title') or project.get('name')} \u2014 generated {date.today().isoformat()}")
    d.add_heading("PRISMA 2020 planning counts", 1)
    t = d.add_table(rows=0, cols=2); t.style = "Light Grid Accent 1"
    nz = lambda v: "___" if v is None else str(v)
    for k, v in [("Records identified (databases)", nz(counts["identified"])), ("Duplicates removed", nz(counts["duplicates_removed"])),
                 ("Unique records in library / screened", counts["library"]), ("Excluded at title/abstract", counts["excluded_title_abstract"]),
                 ("Full texts assessed", counts["full_text_assessed"]), ("Full-text exclusions", counts["excluded_full_text"]),
                 ("Included in the review", counts["included"]), ("Not yet finally decided", counts["unresolved"])]:
        r = t.add_row().cells; r[0].text = k; r[1].text = str(v)
    d.add_paragraph("Counts come only from recorded decisions. Use the official PRISMA 2020 template for the manuscript.")
    if counts["reasons"]:
        d.add_heading("Exclusion reasons", 2)
        for k, v in counts["reasons"].items(): d.add_paragraph(f"{k}: {v}", style="List Bullet")
    d.add_heading(f"Included articles ({len(included)})", 1)
    tb = d.add_table(rows=1, cols=5); tb.style = "Light Grid Accent 1"
    for c, h in zip(tb.rows[0].cells, ["#", "Authors", "Year", "Title", "DOI"]): c.text = h
    for i, a in enumerate(included):
        r = tb.add_row().cells
        for c, v in zip(r, [i + 1, first_author(a) + (" et al." if len((a.get("authors") or "").split(";")) > 2 else ""), a.get("year") or "", a.get("title") or "", a.get("doi") or ""]): c.text = str(v)
    d.add_heading("References", 1)
    for line in references_text(included).splitlines(): d.add_paragraph(line)
    d.save(path)

def proposal_docx(path, project, sections, included):
    from docx import Document
    d = Document(); d.add_heading(project.get("review_title") or project.get("name") or "Project information", 0)
    d.add_paragraph(f"Discipline: {project.get('discipline') or '[Specify]'} \u00b7 Prepared {date.today().isoformat()}")
    for name in SECTIONS:
        d.add_heading(name, 1)
        for line in (sections.get(name) or "").splitlines():
            if line.strip(): d.add_paragraph(line)
    d.add_heading("9. References", 1)
    for line in references_text(included).splitlines(): d.add_paragraph(line)
    d.add_paragraph("Draft generated locally from records with a final Include decision. Verify every source, quotation and claim before submission.")
    d.save(path)

def proposal_md(project, sections, included):
    md = [f"# {project.get('review_title') or project.get('name')}", ""]
    for n in SECTIONS: md += [f"## {n}", "", sections.get(n) or "", ""]
    md += ["## 9. References", "", references_text(included), ""]
    return "\n".join(md)

def source_pack(project, counts, included, sections, tmpdir):
    """NotebookLM-style source pack: report, extraction sheet, RIS, draft, and one text file per included article."""
    import os
    from tempfile import NamedTemporaryFile
    mem = io.BytesIO()
    with zipfile.ZipFile(mem, "w", zipfile.ZIP_DEFLATED) as z:
        for fname, fn in (("01_results_report.docx", lambda p: results_docx(p, project, counts, included)),
                          ("02_project_information.docx", lambda p: proposal_docx(p, project, sections, included))):
            tmp = NamedTemporaryFile(suffix=".docx", delete=False, dir=tmpdir); tmp.close(); fn(tmp.name); z.write(tmp.name, fname); os.unlink(tmp.name)
        z.writestr("03_extraction_sheet.csv", csv_bytes(extraction_rows(included)))
        z.writestr("04_included_references.ris", ris_bytes(included))
        z.writestr("05_project_information.md", proposal_md(project, sections, included))
        for i, a in enumerate(included):
            ft = re.sub(r"\[\[PAGE:(\d+)\]\]", r"[Page \1]", a.get("full_text") or "(not imported)")
            body = f"{reference(a)}\n\nABSTRACT\n{a.get('abstract') or '(none)'}\n\nKEYWORDS\n{a.get('keywords') or ''}\n\nFULL TEXT\n{ft}"
            safe = re.sub(r"[^A-Za-z0-9]+", "_", first_author(a) + "_" + str(a.get("year") or "nd") + "_" + (a.get("title") or "")[:40]).strip("_")
            z.writestr(f"sources/S{i+1:03d}_{safe}.txt", body)
    return mem.getvalue()
