"""Crossref metadata lookup. Network calls occur only when a reviewer requests them."""
import json, re, urllib.parse, urllib.request
from .metadata import normalize_doi

API = "https://api.crossref.org/works"

def _get(url, timeout=12):
    req = urllib.request.Request(url, headers={
        "User-Agent": "ResearchMateAI/1.1 (local research screening tool; mailto:researchmate@example.org)",
        "Accept": "application/json"
    })
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8"))

def _year(item):
    for key in ("published-print", "published-online", "issued", "created"):
        date = item.get(key, {}).get("date-parts", [])
        if date and date[0]:
            try: return int(date[0][0])
            except (ValueError, TypeError): pass
    return None

def _authors(item):
    names=[]
    for a in item.get("author", []) or []:
        name=" ".join(x for x in [a.get("given",""), a.get("family","")] if x).strip()
        if name: names.append(name)
    return "; ".join(names)

def _clean(item):
    title=(item.get("title") or [""])[0]
    journal=(item.get("container-title") or [""])[0]
    abstract=re.sub(r"<[^>]+>", " ", item.get("abstract") or "")
    abstract=re.sub(r"\s+", " ", abstract).strip()
    doi=normalize_doi(item.get("DOI",""))
    return {"title":title, "authors":_authors(item), "year":_year(item), "doi":doi,
            "journal":journal, "abstract":abstract, "publisher":item.get("publisher",""),
            "type":item.get("type",""), "url":item.get("URL",""),
            "source":"Crossref", "crossref_score":item.get("score")}

def lookup_doi(doi):
    doi=normalize_doi(doi)
    if not doi: raise ValueError("No DOI is stored for this record. Enter or verify the DOI first.")
    url=API+"/"+urllib.parse.quote(doi, safe="/")
    payload=_get(url)
    item=payload.get("message")
    if not item: raise ValueError("Crossref returned no work for this DOI.")
    actual=normalize_doi(item.get("DOI",""))
    if actual and actual != doi:
        raise ValueError("Crossref returned a DOI that does not match the requested DOI; metadata was not applied.")
    return _clean(item)

def search_title(title):
    title=(title or "").strip()
    if not title: raise ValueError("Article title is empty.")
    params=urllib.parse.urlencode({"query.title":title, "rows":5, "select":"DOI,title,author,published-print,published-online,issued,created,container-title,abstract,publisher,type,URL,score"})
    payload=_get(API+"?"+params)
    items=payload.get("message",{}).get("items",[])
    return [_clean(item) for item in items]
