
import re
def split_terms(v): return [x.strip() for x in re.split(r"[\n,;]+",v or "") if x.strip()]
def evidence_snippet(text,term,window=180):
 m=re.search(re.escape(term),text,re.I)
 if not m: return None
 start=max(0,m.start()-window//2); end=min(len(text),m.end()+window//2)
 page_matches=list(re.finditer(r"\[\[PAGE:(\d+)\]\]", text[:m.start()]))
 page=int(page_matches[-1].group(1)) if page_matches else None
 quote=re.sub(r"\[\[PAGE:\d+\]\]", "", text[start:end])
 return {"term":term,"quote":re.sub(r"\s+"," ",quote).strip(),"char_start":start,"char_end":end,"page":page}
def tfidf_score(query,doc):
 try:
  from sklearn.feature_extraction.text import TfidfVectorizer
  from sklearn.metrics.pairwise import cosine_similarity
  mat=TfidfVectorizer(stop_words="english",ngram_range=(1,2),max_features=30000).fit_transform([query,doc])
  return float(cosine_similarity(mat[0:1],mat[1:2])[0][0])
 except Exception: return None
def embedding_score(query,doc):
 try:
  from sentence_transformers import SentenceTransformer
  global _MODEL
  try: model=_MODEL
  except NameError:
   model=SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2"); _MODEL=model
  vec=model.encode([query,doc],normalize_embeddings=True)
  return float(vec[0] @ vec[1])
 except Exception: return None
def screen(article,criteria,semantic_mode="tfidf"):
 text=" ".join(str(article.get(k) or "") for k in ["title","abstract","keywords","full_text","journal","article_type"])
 lower=text.lower(); required=split_terms(criteria.get("required_terms")); any_terms=split_terms(criteria.get("any_terms")); excluded=split_terms(criteria.get("excluded_terms"))
 start=int(criteria.get("year_start") or 2015); end=int(criteria.get("year_end") or 2026)
 result={}; evidence=[]; hard=[]; warnings=[]
 try: year=int(article.get("year")) if article.get("year") not in ("",None) else None
 except (TypeError,ValueError): year=None
 if year is None: result["publication_year"]="unknown"; warnings.append("Publication year not verified")
 elif start<=year<=end: result["publication_year"]="pass"
 else: result["publication_year"]="fail"; hard.append(f"Publication year {year} outside {start}–{end}")
 missing=[]
 for term in required:
  if term.lower() in lower:
   result["required:"+term]="pass"; ev=evidence_snippet(text,term)
   if ev: evidence.append({"criterion":"required_term",**ev})
  else: result["required:"+term]="not_found"; missing.append(term)
 found=[t for t in any_terms if t.lower() in lower]
 result["any_of_terms"]="pass" if not any_terms or found else "not_found"
 for term in found[:10]:
  ev=evidence_snippet(text,term)
  if ev: evidence.append({"criterion":"any_of_term",**ev})
 flagged=[t for t in excluded if t.lower() in lower]
 result["potential_exclusion_terms"]="flagged" if flagged else "none_found"
 for term in flagged:
  ev=evidence_snippet(text,term)
  if ev: evidence.append({"criterion":"potential_exclusion_term",**ev})
 query=" ".join([criteria.get("review_title",""),criteria.get("discipline",""),criteria.get("research_question","")," ".join(required)," ".join(any_terms)]).strip()
 doc=" ".join([article.get("title") or "",article.get("abstract") or "",article.get("keywords") or "",(article.get("full_text") or "")[:20000]])
 score=embedding_score(query,doc) if semantic_mode=="embeddings" else None
 method="sentence-transformers" if score is not None else "none"
 if score is None and semantic_mode in ("embeddings","tfidf"):
  score=tfidf_score(query,doc); method="tfidf" if score is not None else "none"
 result["semantic_similarity"]=round(score,4) if score is not None else None
 if hard: decision="Exclude"; reason="; ".join(hard)
 elif warnings or missing or (any_terms and not found) or flagged:
  decision="Uncertain"; parts=warnings[:]
  if missing: parts.append("Required terms not found (not conclusive): "+", ".join(missing))
  if any_terms and not found: parts.append("No any-of terms found (not conclusive)")
  if flagged: parts.append("Potential exclusion terms need review: "+", ".join(flagged))
  reason="; ".join(parts)
 else: decision="Uncertain"; reason="Terms matched; verify research task, document type, peer review, and full text."
 return {"decision":decision,"reason":reason,"score":score,"method":method,"criterion_results":result,"evidence":evidence,"reviewer_required":True}
