import re, hashlib
from pathlib import Path
from rapidfuzz import fuzz

def file_hash(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def normalize_doi(value):
    value = (value or "").strip()
    value = re.sub(r"^(?:https?://)?(?:dx\.)?doi\.org/", "", value, flags=re.I)
    value = re.sub(r"^doi\s*:\s*", "", value, flags=re.I)
    return value.strip().rstrip(".,;:)]}").lower()

def extract_abstract(text):
    m = re.search(r"\babstract\b\s*[:.]?\s*(.{80,6000}?)(?=\n\s*(?:keywords?|1\s*\.?\s*introduction|introduction)\b)", text, re.I | re.S)
    return re.sub(r"\s+", " ", m.group(1)).strip()[:5000] if m else ""

def metadata_from_text(text, path, meta=None):
    meta = meta or {}
    lines = [re.sub(r"\s+", " ", x).strip() for x in text.splitlines() if x.strip() and not re.match(r"^\[\[PAGE:\d+\]\]$", x.strip())]
    dm = re.search(r"\b(?:doi\s*:\s*)?(10\.\d{4,9}/[^\s\"<>]+)", text, re.I)
    doi = normalize_doi(dm.group(1)) if dm else ""
    years = re.findall(r"\b(19\d{2}|20\d{2})\b", text[:20000])
    year = int(years[0]) if years else None
    title = (meta.get("title") or "").strip()
    if not title or title.lower() in {"untitled", "microsoft word"}:
        cand = [x for x in lines[:30] if 20 <= len(x) <= 300 and not re.search(r"10\.\d{4,9}/", x) and not re.match(r"^(abstract|keywords?|introduction|doi|issn)\b", x, re.I)]
        title = max(cand[:12], key=len) if cand else Path(path).stem
    return {"title": title, "authors": meta.get("author") or "", "year": year, "doi": doi, "journal": "",
            "article_type": "journal article" if Path(path).suffix.lower() in {".pdf", ".docx"} else "",
            "abstract": extract_abstract(text), "keywords": ""}

def extract_file(path):
    p = Path(path); ext = p.suffix.lower(); text = ""; meta = {}; page_count = 0
    if ext == ".pdf":
        import fitz
        doc = fitz.open(str(p)); meta = dict(doc.metadata or {}); page_count = len(doc)
        chunks = []
        for i, page in enumerate(doc, start=1):
            chunks.append(f"[[PAGE:{i}]]\n" + page.get_text("text"))
        text = "\n".join(chunks)[:1500000]
    elif ext == ".docx":
        from docx import Document
        doc = Document(str(p)); text = "\n".join(x.text for x in doc.paragraphs)[:1500000]
        meta = {"title": doc.core_properties.title or "", "author": doc.core_properties.author or ""}
    elif ext == ".txt":
        text = p.read_text(encoding="utf-8", errors="replace")[:1500000]
    rec = metadata_from_text(text, str(p), meta)
    rec.update({"full_text": text, "file_path": str(p), "sha256": file_hash(path),
                "file_size": p.stat().st_size, "pdf_metadata": {**meta, "_page_count": page_count}})
    return rec

def title_similarity(a, b):
    return fuzz.token_set_ratio(a or "", b or "") / 100
