
import sqlite3, json
from pathlib import Path
APP_DIR=Path.home()/".researchmate_ai"
APP_DIR.mkdir(parents=True,exist_ok=True)
DB_PATH=APP_DIR/"researchmate_advanced.db"
SCHEMA="""
CREATE TABLE IF NOT EXISTS projects(
 id INTEGER PRIMARY KEY, name TEXT, review_title TEXT, discipline TEXT, research_question TEXT,
 study_area TEXT, year_start INTEGER, year_end INTEGER, required_terms TEXT, any_terms TEXT,
 excluded_terms TEXT, allowed_types TEXT, updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS articles(
 id INTEGER PRIMARY KEY, title TEXT, authors TEXT, year INTEGER, doi TEXT DEFAULT '', journal TEXT,
 article_type TEXT, abstract TEXT, keywords TEXT, full_text TEXT, file_path TEXT, sha256 TEXT,
 file_size INTEGER DEFAULT 0, pdf_metadata TEXT DEFAULT '{}', imported_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE INDEX IF NOT EXISTS idx_articles_title ON articles(title);
CREATE INDEX IF NOT EXISTS idx_articles_doi ON articles(doi);
CREATE INDEX IF NOT EXISTS idx_articles_hash ON articles(sha256);
CREATE TABLE IF NOT EXISTS screening(
 id INTEGER PRIMARY KEY, article_id INTEGER, decision TEXT, score REAL, method TEXT,
 criterion_results TEXT, evidence_json TEXT, primary_reason TEXT, reviewer TEXT,
 reviewer_notes TEXT, is_final INTEGER DEFAULT 0, reviewed_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS audit_log(
 id INTEGER PRIMARY KEY, entity_type TEXT, entity_id INTEGER, action TEXT, actor TEXT,
 old_value TEXT, new_value TEXT, details TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS drafts(
 section TEXT PRIMARY KEY, body TEXT, edited INTEGER DEFAULT 0, updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS duplicate_scans(
 id INTEGER PRIMARY KEY, root_path TEXT, files_scanned INTEGER, duplicate_groups INTEGER,
 scanned_at TEXT DEFAULT CURRENT_TIMESTAMP);
"""
NEW_PROJECT_COLS=["objectives","search_strategy","db_counts","work_plan"]
PROJECT_KEYS=["name","review_title","discipline","research_question","study_area","year_start","year_end","required_terms","any_terms","excluded_terms","allowed_types"]+NEW_PROJECT_COLS
def connect():
 c=sqlite3.connect(DB_PATH); c.row_factory=sqlite3.Row; c.execute("PRAGMA foreign_keys=ON"); return c
def audit(c, typ, eid, action, actor="Researcher", old="", new="", details=""):
 c.execute("INSERT INTO audit_log(entity_type,entity_id,action,actor,old_value,new_value,details) VALUES(?,?,?,?,?,?,?)",
           (typ,eid,action,actor,old,new,details))
def initialize():
 with connect() as c:
  c.executescript(SCHEMA)
  have={r["name"] for r in c.execute("PRAGMA table_info(projects)")}
  for col in NEW_PROJECT_COLS:
   if col not in have: c.execute(f"ALTER TABLE projects ADD COLUMN {col} TEXT DEFAULT ''")
  if not c.execute("SELECT 1 FROM projects LIMIT 1").fetchone():
   c.execute("""INSERT INTO projects(name,review_title,discipline,year_start,year_end,required_terms,any_terms,excluded_terms,allowed_types)
   VALUES('My Research Project','My literature review','General',2015,2026,'','','','Peer-reviewed original research')""")
def project():
 with connect() as c: return dict(c.execute("SELECT * FROM projects ORDER BY id LIMIT 1").fetchone())
def save_project(d, actor="Researcher"):
 with connect() as c:
  old=dict(c.execute("SELECT * FROM projects ORDER BY id LIMIT 1").fetchone())
  keys=PROJECT_KEYS
  c.execute("UPDATE projects SET "+",".join(k+"=?" for k in keys)+",updated_at=CURRENT_TIMESTAMP WHERE id=?",
            [d.get(k,"") for k in keys]+[old["id"]])
  audit(c,"project",old["id"],"criteria_updated",actor,json.dumps(old,ensure_ascii=False),json.dumps(d,ensure_ascii=False),"Project criteria updated")
def add_article(d, actor="Researcher"):
 with connect() as c:
  doi=(d.get("doi") or "").lower().replace("https://doi.org/","").strip()
  title=(d.get("title") or "").strip()
  old=None
  if doi: old=c.execute("SELECT id FROM articles WHERE lower(doi)=?",(doi,)).fetchone()
  if old is None and d.get("sha256"): old=c.execute("SELECT id FROM articles WHERE sha256=? AND sha256<>''",(d["sha256"],)).fetchone()
  if old is None and title: old=c.execute("SELECT id FROM articles WHERE lower(trim(title))=?",(title.lower(),)).fetchone()
  if old:
   audit(c,"article",old["id"],"duplicate_import_skipped",actor,"",json.dumps(d,ensure_ascii=False),"Matched DOI, hash, or title")
   return old["id"],False
  keys=["title","authors","year","doi","journal","article_type","abstract","keywords","full_text","file_path","sha256","file_size","pdf_metadata"]
  vals=[title,d.get("authors",""),d.get("year"),doi,d.get("journal",""),d.get("article_type",""),d.get("abstract",""),d.get("keywords",""),d.get("full_text",""),d.get("file_path",""),d.get("sha256",""),d.get("file_size",0),json.dumps(d.get("pdf_metadata",{}),ensure_ascii=False)]
  cur=c.execute("INSERT INTO articles("+",".join(keys)+") VALUES("+",".join("?" for _ in keys)+")",vals)
  aid=cur.lastrowid; audit(c,"article",aid,"imported",actor,"",json.dumps(d,ensure_ascii=False),"Article imported")
  return aid,True
def articles(q=""):
 like="%"+q.strip()+"%"
 with connect() as c:
  rows=c.execute("""SELECT a.*,s.decision,s.score,s.method,s.primary_reason,s.reviewer,s.reviewer_notes,s.is_final,s.reviewed_at
  FROM articles a LEFT JOIN screening s ON s.id=(SELECT MAX(s2.id) FROM screening s2 WHERE s2.article_id=a.id)
  WHERE a.title LIKE ? OR a.authors LIKE ? OR a.doi LIKE ? OR a.journal LIKE ? OR a.abstract LIKE ? OR a.keywords LIKE ? OR a.file_path LIKE ?
  ORDER BY COALESCE(a.year,0) DESC,a.title COLLATE NOCASE""",(like,)*7).fetchall()
  return [dict(r) for r in rows]
def get_article(aid):
 with connect() as c:
  r=c.execute("SELECT * FROM articles WHERE id=?",(aid,)).fetchone(); return dict(r) if r else None
def save_screening(aid,res,reviewer="Researcher",notes="",final=False,actor="Researcher"):
 with connect() as c:
  prev=c.execute("SELECT * FROM screening WHERE article_id=? ORDER BY id DESC LIMIT 1",(aid,)).fetchone()
  old=json.dumps(dict(prev),ensure_ascii=False) if prev else ""
  c.execute("""INSERT INTO screening(article_id,decision,score,method,criterion_results,evidence_json,primary_reason,reviewer,reviewer_notes,is_final)
  VALUES(?,?,?,?,?,?,?,?,?,?)""",(aid,res.get("decision","Uncertain"),res.get("score"),res.get("method",""),
   json.dumps(res.get("criterion_results",{}),ensure_ascii=False),json.dumps(res.get("evidence",[]),ensure_ascii=False),
   res.get("reason",""),reviewer,notes,int(final)))
  audit(c,"screening",aid,"decision_saved",actor,old,json.dumps({"decision":res.get("decision"),"reviewer":reviewer,"final":final,"notes":notes},ensure_ascii=False),"New screening decision record")
def screening_rows():
 with connect() as c:
  return [dict(r) for r in c.execute("""SELECT a.id,a.title,a.authors,a.year,a.doi,a.file_path,
   s.decision,s.score,s.method,s.criterion_results,s.evidence_json,s.primary_reason,s.reviewer,s.reviewer_notes,s.reviewed_at,s.is_final
   FROM articles a LEFT JOIN screening s ON s.id=(SELECT MAX(s2.id) FROM screening s2 WHERE s2.article_id=a.id)
   ORDER BY a.title""").fetchall()]
def audit_rows(limit=500):
 with connect() as c: return [dict(r) for r in c.execute("SELECT * FROM audit_log ORDER BY id DESC LIMIT ?",(limit,)).fetchall()]
def save_scan(root,count,groups):
 with connect() as c: c.execute("INSERT INTO duplicate_scans(root_path,files_scanned,duplicate_groups) VALUES(?,?,?)",(root,count,groups))


def update_article_metadata(aid, values, actor="Researcher"):
 with connect() as c:
  row=c.execute("SELECT * FROM articles WHERE id=?",(aid,)).fetchone()
  if not row: return False
  old=dict(row)
  # Only apply non-empty metadata; retain local full text, paths, hashes, and import data.
  fields=["title","authors","year","doi","journal","abstract"]
  newvals={}
  for key in fields:
   val=values.get(key)
   if val not in (None,"",[]):
    newvals[key]=val
  if not newvals: return False
  c.execute("UPDATE articles SET "+",".join(k+"=?" for k in newvals)+" WHERE id=?",
            list(newvals.values())+[aid])
  audit(c,"article",aid,"crossref_metadata_applied",actor,json.dumps({k:old.get(k) for k in newvals},ensure_ascii=False),
        json.dumps(newvals,ensure_ascii=False),"Metadata sourced from Crossref; reviewer-triggered update")
  return True


def included_articles():
 """Records whose latest decision is a FINAL human Include (full fields, stable order)."""
 with connect() as c:
  rows=c.execute("""SELECT a.*,s.decision,s.primary_reason,s.reviewer,s.reviewer_notes,s.reviewed_at
  FROM articles a JOIN screening s ON s.id=(SELECT MAX(s2.id) FROM screening s2 WHERE s2.article_id=a.id)
  WHERE s.decision='Include' AND s.is_final=1
  ORDER BY lower(COALESCE(a.authors,'')),COALESCE(a.year,0),lower(a.title)""").fetchall()
  return [dict(r) for r in rows]
def duplicate_skip_count():
 with connect() as c: return c.execute("SELECT COUNT(*) FROM audit_log WHERE action='duplicate_import_skipped'").fetchone()[0]
def get_drafts():
 with connect() as c: return {r["section"]:dict(r) for r in c.execute("SELECT * FROM drafts")}
def save_draft(section,body,edited=False):
 with connect() as c:
  c.execute("INSERT INTO drafts(section,body,edited,updated_at) VALUES(?,?,?,CURRENT_TIMESTAMP) ON CONFLICT(section) DO UPDATE SET body=excluded.body,edited=excluded.edited,updated_at=CURRENT_TIMESTAMP",(section,body,int(edited)))
  audit(c,"draft",0,"draft_edited" if edited else "draft_generated","Researcher","",section,"Proposal section saved")
