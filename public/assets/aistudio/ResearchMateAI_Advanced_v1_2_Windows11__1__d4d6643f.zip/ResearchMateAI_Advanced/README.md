# ResearchMate AI Advanced 1.2 — Windows 11

A local-first research desktop-style web application using **Python + Flask + HTML/CSS/JavaScript-compatible browser UI**. It opens in your browser but the backend runs on your own computer at `127.0.0.1`.

## Advanced features
- Searchable article library and import of PDF, DOCX, TXT, RIS, and CSV files.
- Local PDF/DOCX text extraction and heuristic metadata extraction (title, DOI, year, abstract, PDF metadata).
- Reviewer-triggered Crossref metadata lookup by DOI or title. Title results are previewed for comparison; applying metadata is a separate action and is recorded in the audit log.
- Exact duplicate file scanning with SHA-256. No files are deleted.
- Flexible, discipline-independent inclusion terms, any-of terms, exclusion flags, and publication-year limits.
- Evidence snippets with matched term, character offsets, and PDF page numbers when source is a text-based PDF.
- Side-by-side review workspace: article text, evidence cards, page-aware jump controls, and Include / Exclude / Uncertain decision form.
- TF-IDF lexical similarity by default; optional local sentence-transformer embeddings.
- Human reviewer decisions: Include / Exclude / Uncertain; reviewer, notes, final status, timestamps.
- Append-only decision audit trail that records project criteria changes, imports, duplicate import skips, and review decisions.
- Export library and screening records to CSV.
- Proposal scaffold export to editable DOCX based on records with a final human Include decision.

## Install and run on Windows 11
1. Install Python 3.11+ from https://www.python.org/downloads/windows/ (enable Add Python to PATH).
2. Extract this ZIP to a folder such as `C:\ResearchMateAI_Advanced`.
3. Open PowerShell in the extracted folder.
4. Recommended virtual environment:
   ```powershell
   py -m venv .venv
   .\.venv\Scripts\Activate.ps1
   ```
   If activation is blocked in that terminal, run `Set-ExecutionPolicy -Scope Process Bypass` then activate again.
5. Install dependencies:
   ```powershell
   python -m pip install --upgrade pip
   pip install -r requirements.txt
   ```
6. Start:
   ```powershell
   python main.py
   ```
7. Open `http://127.0.0.1:8765` if the browser does not open automatically. Stop the app with Ctrl+C in the terminal.

A `run_windows.bat` launcher is included. The app is bound to localhost only; do not change the host to `0.0.0.0` unless you understand the network exposure implications.

## Optional semantic embeddings
The default TF-IDF score is lexical similarity, not deep semantic understanding. To enable sentence-transformer embeddings:
```powershell
pip install sentence-transformers
```
Choose **Local sentence-transformer embeddings** on the screening page. The first run may download the `all-MiniLM-L6-v2` model and requires internet access. Model files are then cached locally. If model loading fails, the screening engine falls back to TF-IDF.

## Build a Windows executable (optional)
```powershell
pip install pyinstaller
pyinstaller --noconfirm --name ResearchMateAIAdvanced --add-data "researchmate;researchmate" main.py
```
Because Flask uses templates rendered from Python strings in this version, there are no external template folders to bundle. Test the build on your Windows machine before relying on it.

## Database and source files
- Database: `%USERPROFILE%\.researchmate_ai\researchmate_advanced.db`
- Imported copies: `%USERPROFILE%\.researchmate_ai\imports\`

Back up the database and imports folder with the app closed.

## Screening methodology and limitations
- Keyword absence and potential exclusion terms produce **Uncertain**, not automatic exclusion. The publication-year rule can exclude records outside the configured range.
- Peer review, article type, actual research task, and full-text eligibility require human verification. The app does not verify peer review online.
- Metadata extraction is heuristic. Crossref lookup requires internet access and may not cover every publication. Always compare the returned title, authors, year, DOI, journal, and abstract against the PDF/publisher record; title-search results are never applied automatically.
- Page numbers are inferred from extracted text markers for text-based PDFs. Scanned PDFs without OCR may have little/no searchable text; page-level references are not guaranteed for DOCX/TXT or if page markers are absent.
- Similarity scores are triage aids, not eligibility probabilities.
- Audit events are append-only in the interface; this is not cryptographically tamper-proof.
- Proposal generation creates a structured draft. It does not write a fully evidence-grounded literature review automatically and must not be submitted without researcher review.
- This app does not perform scholarly database searches or send data to a cloud AI provider.

## Suggested pilot test
Before a large review, import 20–50 known records spanning obvious inclusions, obvious exclusions, duplicates, missing metadata, and borderline studies. Verify screening decisions, evidence snippets, reviewer logs, and exports.


## New review workflow
- Open a record from the screening page to use the side-by-side reviewer workspace.
- PDF text is extracted with `[[PAGE:N]]` markers. Evidence cards display a page number when the match can be mapped to a PDF page and include a **Locate in text** control.
- Use **Check DOI with Crossref** to preview a DOI match. Use **Search Crossref by title** if the DOI is missing or suspect. Compare candidates before applying one; applying metadata adds an audit event.
- Crossref is a bibliographic registry, not a guarantee of publisher correctness or peer-review status. The user should verify metadata and eligibility manually.


## New in 1.2 — Output results and referenced project-information writer
- **Output results** (nav): built only from records with a *final human Include* decision under the current project criteria. Shows PRISMA 2020 planning counts (identified, duplicates removed, screened, title/abstract exclusions, full texts assessed, full-text exclusions, included), exclusion reasons and the included-article table. Downloads: Word results report, extraction-sheet CSV (guide section 7 columns, one row per study), RIS references, and a **source pack ZIP** (report, project information, CSV, RIS, Markdown, and one text file per included article) for use as sources in tools such as NotebookLM.
- **Full-text exclusions:** start the exclusion reason with `FT` (e.g. `FT-02 no UAV data`) so PRISMA separates them from title/abstract exclusions.
- **Project information writer:** writes the sections *Background and rationale, Problem statement, Research aim and objectives, Research questions, Literature review and research gap, Methodology, Expected outputs, Work plan, References*. Everything runs locally. Cited sentences are extracted from abstracts of final-included records and numbered [n]; the reference list is built from your library. The literature section groups evidence by theme and reports gap counts from title/abstract/keyword matching. Methodology is assembled from your recorded databases, search string, criteria and counts. You can edit any section; edited sections are kept, others refresh as data change.
- **Project page:** new fields for objectives, search strategy, databases (`name | search date | records`) and work-plan notes, plus a button that loads the UAV crop-health systematic-review template (RQ1–RQ7, objectives, terms, search string). Existing 1.1 databases upgrade automatically.
- **Limits:** the writer is extractive, not a language model; it does not paraphrase or judge evidence. Rewrite and verify every passage against the full article before submission. Gap counts are not a substitute for an evidence matrix.
